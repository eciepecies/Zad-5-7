package com.zetcode;


import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
public class KOD_EDYCJA {
 BufferedImage image;
 int width;
 int height;

 public KOD_EDYCJA() {

  try {

   File input = new File("Przed_kompilacją.jpg");
   image = ImageIO.read(input);
   width = image.getWidth();
   height = image.getHeight();


   for(int i=0; i<height; i++){
    for(int j=0; j<width; j++){


     Color c = new Color(image.getRGB(j, i));
     int red = (int)(c.getRed());
     int green = (int)(c.getGreen());
     int blue = (int)(c.getBlue());

     int x, y, z;


     x = 0;
     y = 0;
     z = 0;



     if ( i>=500 && i<=3000 && j>=700 && j<=4500 )
     {
      x = -255;
      y = 240;
      z = -255;

     }


     
    if ( i>=1700 && i<=3000 && j>=200 && j<=2500 )


     {
      x = -50;
      y = 220;
      z = 10;

     }


     if ( i>=300 && i<=780 && j>=0 && j<=600 )
     {
      x = 50;
      y = 50;
      z = 50;

     }



     if (red + x>=0 && red + x <=255) red = red + x;
     else red = red;

     if (green + y>=0 && green + y <=255) green = green + y;
     else green = green;

     if (blue + z>=0 && blue + z <=255) blue = blue + z;
     else blue = blue;


     Color newColor = new Color(red, green,blue);
     image.setRGB(j,i,newColor.getRGB());

    }
   }

   File ouptut = new File("Po_kompilacji.jpg");
   ImageIO.write(image, "jpg", ouptut);

  } catch (IOException e) {}
 }

 static public void main(String args[]) throws Exception
 {
  KOD_EDYCJA obj = new KOD_EDYCJA();
 }
}
